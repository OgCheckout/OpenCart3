<?php
// Heading
$_['default_title']					 = 'Ogpay';
$_['default_description']			 = 'You will be redirect to Ogpay Secure page';
?>