<?php
// Heading
$_['heading_title']					 = 'Og Pay';

// Text
$_['text_extension']		 		 = 'Extensions';
$_['text_ogpay']				     = '<img src="https://ogpayadmin.oneglobal.com/pgimages/ogpay.png" alt="OG Pay" title="OG Pay" style="width:40px;border: 1px solid #fff;" />';
$_['text_payment']					 = 'Payment';
$_['text_success']					 = 'Success: You have modified Og Pay account details!';
$_['text_success_connect']			 = 'Success: You have connected your PayPal (Powered by Og Pay) account!';
$_['text_edit']						 = 'Edit Og Pay';
$_['text_currency']					 = 'Currency';
$_['text_yes']						 = 'Yes';
$_['text_no']						 = 'No';
$_['text_unlink']		 			 = 'Delete link';

// Column

$_['column_action']					 = 'Action';
$_['column_amount']					 = 'Amount';
$_['column_status']					 = 'Status';
$_['column_type']					 = 'Type';
$_['column_customer']				 = 'Customer';
$_['column_order']					 = 'Order';
$_['column_date_added']				 = 'Date Added';

// Entry
$_['entry_checkout_title']		     = 'Checkout Title';
$_['entry_checkout_description']	 = 'Checkout Description';
$_['entry_status']                   = 'Status';
$_['entry_merchant_name']			 = 'Merchant Name';
$_['entry_auth_key']				 = 'Auth Key';
$_['entry_secret_key']				 = 'Secret Key';
$_['entry_callback_url']			 = 'Callback URL';
$_['entry_endpoint_url']             = 'Endpoint Url';
$_['entry_ogpay_country']			 = 'Country';
$_['entry_ogpay_language']			 = 'Language';
$_['entry_ogpay_tunnel']			 = 'Tunnel';
$_['entry_ogpay_currency']			 = 'Currency';
$_['entry_payment_method']           = 'Payment Method';
$_['entry_channel_code']             = 'Channel Code';
$_['entry_currency_code']            = 'Currency Code';
$_['entry_customize_payment_form']   = 'Customize Your Payment Form';
$_['entry_ogpay_payment_form']       = 'Og Pay Payment Form';
$_['entry_payment_currency']         = 'Payment Currency';
$_['entry_checkout_title_placeholder']		     = 'Og Pay';
$_['entry_checkout_description_placeholder']	 = 'You will be redirect to Og Pay Secure Page';
$_['entry_ogpay_language_placeholder']			 = 'EN';
$_['entry_ogpay_ogpayment_placeholder']			 = 'Currency';


// Error
$_['error_ogpay_merchant_name']		     = 'Merchant Name Required!';
$_['error_ogpay_auth_key']	             = 'Auth Key Required!';
$_['error_ogpay_secret_key']             = 'Secret Key Required!';
$_['error_ogpay_endpoint_url']			 = 'Endpoint URL Required!';
$_['error_ogpay_currency']				 = 'Currency Required!';
$_['error_ogpay_language']				 = 'Language Required!';
$_['error_ogpay_payment_method_mode']	 = 'Payment Method Mode Required!';
$_['error_ogpay_customizemethod']        = 'All fields are Required!';
$_['error_ogpay_ogpaymentmethod']              = 'Payment Method Required!';
	
// Tab
$_['tab_general']					 	 = 'General';
$_['keys_url_section']                   = 'Keys & URLs Configuration';
$_['payment_method_configuration']       = 'Payment Methods Configuration';
$_['default_configuration']              = 'Default Configuration';
$_['tab_config']					 	 = 'Configuration';
$_['tab_order_status']				 	 = 'Order Statuses (New Orders)';
$_['tab_paymentconfig']					 = 'Payment Configuration';
$_['tab_paymentchannelconfig']			 = 'Payment Channels Configuration';

// Help
$_['help_callback_url']		 = 'Please leave this field blank to return to default URL';
$_['help_customize_method']		 = 'Example. Debit Card, Credit Card etc';
$_['help_ogpayment_method']		 = 'Refer to Documentation';
$_['help_ogpayment_currency']		 = 'Leave this field blank when you use "all" parameters in payment method';
$_['help_language']		 =  'By default "en" will be used here';



