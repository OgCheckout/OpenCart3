<?php
// Heading
$_['default_title']					 = 'Og Pay';
$_['default_description']			 = 'You will be redirect to Og Pay Secure page';
?>